from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
#from django.contrib.auth.models import User

### GAME Table
class Game(models.Model):
    name = models.CharField(editable=False, max_length = 50, primary_key=True, unique=True)
    cost = models.IntegerField(blank=False, default=0)
    winEarning = models.IntegerField(default = 10)

    # renames the instances of the model with their title name
    # ie., string for representing the object
    def __str__(self):
        return self.name


### LIBRARY Table
"""
class Library(models.Model):
    # This table grows bigger as more games are added
    clicker = models.BooleanField(default = True)
    roshambo = models.BooleanField(default = False)
    tictactoe = models.BooleanField(default = False)
"""

### USER Table
# User (default): username, password
from django.contrib.auth.models import UserManager, AbstractBaseUser, PermissionsMixin
class CustomUserManager(UserManager):
    def _create_user(self, username, password, **extra_fields):
        if not username:
            raise ValueError("No username provided.")

        username = self.normalize_username(username)
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, username=None, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_superuser", False)
        return self._create_user(username, password, **extra_fields)

    def create_superuser(self, username=None, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_superuser", True)
        return self._create_user(username, password, **extra_fields)



class User(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length = 50, primary_key=True, unique=True)
    email = None

    # Data Members
    win = models.IntegerField(default = 0)
    lose = models.IntegerField(default = 0)
    wallet = models.IntegerField(default = 0)
    password = models.CharField(max_length = 50)
    clicker = models.BooleanField(default = False)
    roshambo = models.BooleanField(default = False)
    tictactoe = models.BooleanField(default = False)
    aimtrainer = models.BooleanField(default = False)

    # Permissions
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    # Date
    date_joined = models.DateTimeField(default=timezone.now)
    last_login = models.DateTimeField(blank=True, null=True)

    objects = CustomUserManager()

    USERNAME_FIELD = "username"
    REQUIRED_FIELD = ["username", "password"]

    def __str__(self):
        return self.username

    def buyClicker(self):
        self.wallet -= 0
        self.clicker = True
        self.save()

    def buyRoshambo(self):
        self.wallet -= 50
        self.roshambo = True
        self.save()

    def buyTictactoe(self):
        self.wallet -= 100
        self.tictactoe = True
        self.save()

    def buyAimTrain(self):
        self.wallet -= 300
        self.aimtrainer = True
        self.save()

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"


"""
class User(AbstractUser):
    username = models.CharField(max_length = 50, primary_key=True, unique=True)
    email = None
    password = models.CharField(max_length = 50)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELD = ['username', 'password']


    # Relationships
    library = models.OneToOneField(Library, on_delete=models.CASCADE)

    # Data Members
    win = models.IntegerField(default = 0)
    lose = models.IntegerField(default = 0)
    wallet = models.IntegerField(default = 0)

    def __str__(self):
        return self.username

class Profile(models.Model):
    # Extends USER model provided by Django
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    # One-to-One Relationships
    library = models.OneToOneField(Library, on_delete=models.CASCADE)

    # Define choice for profileImage
    # RED = 'red' because of inconsistent file naming..
    RED = "RED"
    YELLOW = "YLW"
    GREEN = "GRN"
    BLUE = "BLE"
    GREY = "GRY"

    COLORS = [
        (RED, "red"),
        (YELLOW, "Yellow"),
        (GREEN, "Green"),
        (BLUE, "Blue"),
        (GREY, "Grey")
    ]

    # Data Members
    nickname = models.CharField(max_length = 50, default="")
    win = models.IntegerField(default = 0)
    lose = models.IntegerField(default = 0)
    amount = models.IntegerField(default = 0)
    profileImage = models.CharField(max_length=50, choices=COLORS, default=RED)

    def __str__(self):
        return self.user.username


@receiver(post_save, sender=User)
def update_profile_signal(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance, libraryID=Library.objects.create())
    instance.profile.save()
"""