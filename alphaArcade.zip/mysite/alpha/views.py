from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
#from django.contrib.auth.forms import UserCreationForm
from .models import Game
from .forms import CreateAccountForm, GameForm
from django.contrib.auth import get_user_model
User = get_user_model()

## Index Page
def index(request):
    return render(request, "index.html")

## User Login and Authentication Pages
from . import forms
def loginAuth(request):
    form = forms.LoginForm()
    message = ''
    if request.method == 'POST':
        form = forms.LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                return redirect("home")
            else:
                message = 'Login failed!'
    return render(
        request, 'registration/login.html', context={'form': form, 'message': message})


def createAccountAuth(request):
    if request.method == 'POST':
        form = CreateAccountForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.refresh_from_db()
            user.save()

            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')

            user = authenticate(username=username, password=password)

            login(request, user)
            return redirect("home")
    else:
        form = CreateAccountForm()
    return render(request, "registration/createAccount.html", {'form': form})


def logout(request):
    response = HttpResponseRedirect("login.html")
    for cookie in request.COOKIES:
        response.delete_cookie(cookie)
    return response


## Games
def clicker(request):
    if request.method == 'POST':

        form = GameForm(request.POST)

        if form.is_valid():
            # Get the user
            username = form.cleaned_data["username"]
            user = User.objects.get(username=username)

            # Get data from form
            gameResult = form.cleaned_data["gameResult"]
            gameAmount = form.cleaned_data["gameAmount"]
            gameName = form.cleaned_data["gameName"]

            # Get the game object
            game = Game.objects.get(name=gameName);

            # Update the user attributes
            if gameResult == "0":
                user.lose = user.lose + 1
            else:
                user.win = user.win + 1
                user.wallet = user.wallet + (game.winEarning * gameAmount)

            user.save()
            user.refresh_from_db()
            return render(request, 'index.html')

    # If the submit button is not clicked, then take user to the game
    return render(request, "clicker.html")



def roshambo(request):
    if request.method == 'POST':

        form = GameForm(request.POST)

        if form.is_valid():
            # Get the user
            username = form.cleaned_data["username"]
            user = User.objects.get(username=username)

            # Get data from form
            gameResult = form.cleaned_data["gameResult"]
            gameAmount = form.cleaned_data["gameAmount"]
            gameName = form.cleaned_data["gameName"]

            # Get the game object
            game = Game.objects.get(name=gameName);

            # Update the user attributes
            if gameResult == "0":
                user.lose = user.lose + 1
            else:
                user.win = user.win + 1
                user.wallet = user.wallet + (game.winEarning * gameAmount)

            user.save()
            user.refresh_from_db()
            return render(request, 'index.html')

    # If the submit button is not clicked, then take user to the game
    return render(request, "roshambo.html")

def tictactoe(request):
    if request.method == 'POST':

        form = GameForm(request.POST)

        if form.is_valid():
            # Get the user
            username = form.cleaned_data["username"]
            user = User.objects.get(username=username)

            # Get data from form
            gameResult = form.cleaned_data["gameResult"]
            gameAmount = form.cleaned_data["gameAmount"]
            gameName = form.cleaned_data["gameName"]

            # Get the game object
            game = Game.objects.get(name=gameName);

            # Update the user attributes
            if gameResult == "0":
                user.lose = user.lose + 1
            else:
                user.win = user.win + 1
                user.wallet = user.wallet + (game.winEarning * gameAmount)

            user.save()
            user.refresh_from_db()
            return render(request, 'index.html')

    # If the submit button is not clicked, then take user to the game
    return render(request, "tictactoe.html")

def aimTrain(request):
    if request.method == 'POST':

        form = GameForm(request.POST)

        if form.is_valid():
            # Get the user
            username = form.cleaned_data["username"]
            user = User.objects.get(username=username)

            # Get data from form
            gameResult = form.cleaned_data["gameResult"]
            gameAmount = form.cleaned_data["gameAmount"]
            gameName = form.cleaned_data["gameName"]

            # Get the game object
            game = Game.objects.get(name=gameName);

            # Update the user attributes
            if gameResult == "0":
                user.lose = user.lose + 1
            else:
                user.win = user.win + 1
                user.wallet = user.wallet + (game.winEarning * gameAmount)

            user.save()
            user.refresh_from_db()
            return render(request, 'index.html')

    # If the submit button is not clicked, then take user to the game
    return render(request, "aimTrain.html")

def buyRoshamboAttempt(request):
    if request.method == 'POST':

        form = GameForm(request.POST)

        if form.is_valid():
            #Get the user
            username = form.cleaned_data["username"]
            user = User.objects.get(username=username)

            # Get data from form
            buySuccess = form.cleaned_data["buySuccess"]

            # Update the user attributes
            if buySuccess == "1":
                user.buyRoshambo()
                user.save()
                user.refresh_from_db()
                return render(request, 'roshambo.html')


## Game "Submission" Pages
def postGame(request):
    ### MAY NOT WORK -- THIS THEORETICALLY TAKES THE PLACE OF EVERY SINGLE GAME VIEW ABOVE
    # Use a form to scrape the results and then package the data to the next
    # page for database updating
    if request.method == 'POST':
        form = GameForm(request.POST)

        # Get the user
        username = form.cleaned_data.get("username")
        user = User.objects.get(username=username)

        # Get data from form
        gameResult = form.cleaned_data.get("username")
        gameAmount = form.cleaned_data.get("gameAmount")
        gameName = form.cleaned_data.get("gameName")

        # Get the game object
        game = Game.objects.get(name=gameName);

        # Update the user attributes
        if gameResult == "0":
            user.lose = user.lose + 1
        else:
            user.win = user.win + 1

        user.wallet = user.wallet + (game.winEarning * gameAmount)
        user.refresh_from_db()
        user.save()
        return render(request, 'home')

    # If the submit button is not clicked, then take user to the game
    return render(request, "")


## Misc. Pages
def profile(request):
    return render(request, "profile.html")