"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from alpha import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path("admin/", admin.site.urls),
    #path("mysite/alpha/templates/registration/login.html", include("django.contrib.auth.urls")),
    path("mysite/alpha/templates/clicker.html", views.clicker),
    path("mysite/alpha/templates/roshambo.html", views.roshambo),
    path("mysite/alpha/templates/registration/login.html", views.loginAuth, name="login"),
    path("mysite/alpha/templates/index.html", views.index, name="home"),
    path("mysite/alpha/templates/registration/createAccount.html", views.createAccountAuth),
    path("mysite/alpha/templates/profile.html", views.profile),
    path("mysite/alpha/templates/tictactoe.html", views.tictactoe),
    path("mysite/alpha/templates/aimTrain.html", views.aimTrain),
    path("mysite/alpha/templates/registration/logout.html", views.logout),
    path("mysite/alpha/templates/postGame.html", views.postGame)
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
# Note that + static(...) only works in debug mode!
